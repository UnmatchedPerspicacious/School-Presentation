import { ChevronDown } from 'lucide-react'

export default function Hero() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <section 
      id="hero" 
      className="min-h-screen flex flex-col items-center justify-center px-6 pt-20 relative"
    >
      <div className="max-w-4xl mx-auto text-center">
        <div className="mb-6">
          <span className="text-primary text-sm tracking-widest uppercase">
            Presentation of Learning
          </span>
        </div>
        
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight text-balance">
          מצגת למידה
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-12 leading-relaxed text-pretty">
          מסע של צמיחה, למידה, ויצירת קשרים משמעותיים. 
          בואו נצלול יחד לתהליך שעברתי השנה.
        </p>

        <div className="flex flex-wrap justify-center gap-4">
          <button
            onClick={() => scrollToSection('friendships')}
            className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors"
          >
            בואו נתחיל
          </button>
          <button
            onClick={() => scrollToSection('journey')}
            className="px-8 py-3 border border-border rounded-lg font-medium hover:bg-secondary transition-colors"
          >
            לתהליך המלא
          </button>
        </div>
      </div>

      <button
        onClick={() => scrollToSection('friendships')}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-muted-foreground hover:text-primary transition-colors"
        aria-label="Scroll down"
      >
        <ChevronDown size={32} />
      </button>

      {/* Decorative elements */}
      <div className="absolute top-1/4 right-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-10 w-96 h-96 bg-primary/3 rounded-full blur-3xl pointer-events-none" />
    </section>
  )
}
