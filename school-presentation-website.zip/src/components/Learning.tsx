import { BookOpen, Brain, Lightbulb, Target } from 'lucide-react'

const learningAreas = [
  {
    icon: BookOpen,
    title: 'נושאים אקדמיים',
    items: ['מתמטיקה', 'מדעים', 'שפות', 'היסטוריה'],
  },
  {
    icon: Brain,
    title: 'מיומנויות חשיבה',
    items: ['חשיבה ביקורתית', 'פתרון בעיות', 'יצירתיות', 'ניתוח'],
  },
  {
    icon: Lightbulb,
    title: 'גילויים חדשים',
    items: ['תחומי עניין חדשים', 'כישרונות נסתרים', 'דרכי למידה', 'השראות'],
  },
  {
    icon: Target,
    title: 'מטרות שהושגו',
    items: ['שיפור בציונים', 'הבנה עמוקה', 'עצמאות', 'התמדה'],
  },
]

export default function Learning() {
  return (
    <section id="learning" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-primary text-sm tracking-widest uppercase mb-4 block">
            לימודית
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            מה למדתי
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            הצמיחה האקדמית והאישית שחוויתי לאורך מסע הלמידה שלי.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {learningAreas.map((area, index) => (
            <div
              key={index}
              className="p-8 bg-card rounded-xl border border-border hover:shadow-lg hover:shadow-primary/5 transition-all duration-300"
            >
              <div className="flex items-start gap-6">
                <div className="w-14 h-14 bg-primary/10 rounded-lg flex items-center justify-center shrink-0">
                  <area.icon className="w-7 h-7 text-primary" />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold mb-4">{area.title}</h3>
                  <ul className="space-y-2">
                    {area.items.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-muted-foreground">
                        <span className="w-1.5 h-1.5 bg-primary rounded-full" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 grid md:grid-cols-3 gap-8 text-center">
          <div className="p-6">
            <div className="text-4xl md:text-5xl font-bold text-primary mb-2">85%</div>
            <p className="text-muted-foreground">שיפור בהבנה</p>
          </div>
          <div className="p-6">
            <div className="text-4xl md:text-5xl font-bold text-primary mb-2">12</div>
            <p className="text-muted-foreground">נושאים חדשים</p>
          </div>
          <div className="p-6">
            <div className="text-4xl md:text-5xl font-bold text-primary mb-2">100%</div>
            <p className="text-muted-foreground">מוטיבציה</p>
          </div>
        </div>
      </div>
    </section>
  )
}
