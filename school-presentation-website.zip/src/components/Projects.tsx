import { ExternalLink, Code, Palette, Presentation, Wrench } from 'lucide-react'

const projects = [
  {
    icon: Code,
    title: 'פרוייקט טכנולוגי',
    description: 'פיתחתי אפליקציה/אתר שפותר בעיה אמיתית',
    tags: ['תכנות', 'עיצוב', 'פתרון בעיות'],
    color: 'from-blue-500/20 to-cyan-500/20',
  },
  {
    icon: Palette,
    title: 'פרוייקט יצירתי',
    description: 'יצרתי משהו ייחודי שמביע את עצמי',
    tags: ['יצירתיות', 'אמנות', 'ביטוי עצמי'],
    color: 'from-purple-500/20 to-pink-500/20',
  },
  {
    icon: Presentation,
    title: 'פרוייקט מחקר',
    description: 'חקרתי נושא שמעניין אותי לעומק',
    tags: ['מחקר', 'ניתוח', 'כתיבה'],
    color: 'from-amber-500/20 to-orange-500/20',
  },
  {
    icon: Wrench,
    title: 'פרוייקט מעשי',
    description: 'בניתי משהו בידיים שלי מאפס',
    tags: ['בנייה', 'תכנון', 'ביצוע'],
    color: 'from-emerald-500/20 to-teal-500/20',
  },
]

export default function Projects() {
  return (
    <section id="projects" className="py-24 px-6 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-primary text-sm tracking-widest uppercase mb-4 block">
            פרוייקטים
          </span>
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            מה יצרתי
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            הפרוייקטים שעבדתי עליהם ויצרתי לאורך מסע הלמידה שלי.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className={`relative p-8 rounded-xl border border-border overflow-hidden group hover:border-primary/50 transition-all duration-300 bg-gradient-to-br ${project.color}`}
            >
              <div className="relative z-10">
                <div className="flex items-start justify-between mb-6">
                  <div className="w-14 h-14 bg-background/80 rounded-lg flex items-center justify-center">
                    <project.icon className="w-7 h-7 text-primary" />
                  </div>
                  <button className="p-2 text-muted-foreground hover:text-primary transition-colors opacity-0 group-hover:opacity-100">
                    <ExternalLink size={20} />
                  </button>
                </div>
                
                <h3 className="text-xl font-semibold mb-4">{project.title}</h3>
                <p className="text-muted-foreground mb-6">{project.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-background/80 rounded-full text-sm text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-4">
            רוצים לראות יותר מהעבודות שלי?
          </p>
          <button className="px-8 py-3 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">
            לכל הפרוייקטים
          </button>
        </div>
      </div>
    </section>
  )
}
